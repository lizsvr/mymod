akbarvpn="raw.githubusercontent.com/senowahyu62/scriptvps/main/backup"

wget https://${akbarvpn}/rclone.conf

git clone  https://github.com/magnific0/wondershaper.git

wget -O autobackup "https://${akbarvpn}/autobackup.sh"
wget -O backup "https://${akbarvpn}/backup.sh"
wget -O restore "https://${akbarvpn}/restore.sh"
wget -O strt "https://${akbarvpn}/strt.sh"
wget -O limitspeed "https://${akbarvpn}/limitspeed.sh"
