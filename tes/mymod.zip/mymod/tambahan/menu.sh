#!/bin/bash
m="\033[0;1;36m"
y="\033[0;1;37m"
yy="\033[0;1;32m"
yl="\033[0;1;33m"
nw="\e[38;5;82m"
wh="\033[0m"
blue="\e[38;5;21m"
bred="\e[41m"
#pkg install ncurses-utils
clear
echo -e "$blue─────────────────────────────────────$wh"
echo -e "$bred           𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐃𝐚𝐭𝐚𝐧𝐠            $wh"
echo -e "$blue─────────────────────────────────────$wh"
echo -e "$yl         __   _     ____               "
echo -e "        / /  (_)__ / __/  ______       "
echo -e "       / /__/ /_ /_\ \| |/ / __/       "
echo -e "      /____/_//__/___/|___/_/          $wh"
echo -e "$wh"
echo -e "Mod by LIZ"
echo -e "$blue─────────────────────────────────────$wh"
echo -e "$bred                𝐌𝐞𝐧𝐮                 $wh"
echo -e "$blue─────────────────────────────────────$wh"
echo -e "$yy 1$y. Create Account Vmess"
echo -e "$yy 2$y. Delete Account Vmess"
echo -e "$yy 3$y. Change Port Vmess"
echo -e "$yy 4$y. Cek Account Vmess Login"
echo -e "$yy 5$y. Change Domain"
echo -e "$yy 6$y. Update Cert Vmess"
echo -e "$yy 7$y. Other Menu"
echo -e "$yy 8$y. Exit"
echo -e "$blue─────────────────────────────────────$wh"
read -p "Select From Options [ 1 - 8 ] : " menu

case $menu in 
1)
addssh
;;
2)
clear
;;
3)
addssh
;;
4)
addssh
;;
5)
addssh
;;
6)
addssh
;;
7)
addssh
;;
8)
clear
exit
;;
*)
clear
menu
;;
esacsac