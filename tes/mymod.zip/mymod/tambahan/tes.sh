#!/bin/bash

contoh= /sdcard/mymod/text.txt

$contoh
