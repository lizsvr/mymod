random_num=$((RANDOM%12+4))
#Generate fake path
camouflage="/$(head -n 10 /dev/urandom | md5sum | head -c ${random_num})/"
echo "$camouflage"