#!/bin/bash
# ==========================================
# Link Hosting Kalian
akbarvpn="raw.githubusercontent.com/senowahyu62/scriptvps/main/ssh"

# Link Hosting Kalian Untuk Xray
akbarvpnn="raw.githubusercontent.com/senowahyu62/scriptvps/main/xray"

# Link Hosting Kalian Untuk Trojan Go
akbarvpnnn="raw.githubusercontent.com/senowahyu62/scriptvps/main/trojango"

# Link Hosting Kalian Untuk Stunnel5
#akbarvpnnnn="raw.githubusercontent.com/senowahyu62/scriptvps/main/stunnel5"

#wget "https://${akbarvpn}/password"

#wget "https://${akbarvpn}/index.html1"

#wget "https://${akbarvpn}/badvpn-udpgw64"

#wget "https://${akbarvpn}/squid3.conf"

#wget "https://${akbarvpnnnn}/stunnel5.zip"

#wget "https://${akbarvpnnnn}/stunnel5.init"

#wget "https://${akbarvpn}/vpn.sh"

#wget "https://${akbarvpn}/bbr.sh"

#wget "https://${akbarvpn}/issue.net"

wget https://${akbarvpn}/nginx.conf
wget https://${akbarvpn}/vps.conf
#wget "https://${akbarvpn}/index.html1"
#wget https://humdi.net/vnstat/vnstat-2.6.tar.gz